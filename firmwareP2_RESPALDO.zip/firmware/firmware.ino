#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include "DHT.h"

// Configuración de red Wi-Fi y Broker MQTT
const char* ssid = "Andres";             // <-- nombre deWi-Fi
const char* password = "Mimillita.";         // <-- contraseña de Wi-Fi
const char* mqtt_server = "172.20.10.3";      // <-- IP dcomputadora (servidor)

// Configuración de Pines y Sensores
#define DHTPIN 4
#define DHTTYPE DHT11
#define MQ7PIN 34

DHT dht(DHTPIN, DHTTYPE);
WiFiClient espClient;
PubSubClient client(espClient);

// Tiempos no bloqueantes
unsigned long previousMillis = 0;
const long interval = 2500; // Envío cada 2.5 segundos

// Filtro Promedio Móvil (Ventana N = 10)
const int WINDOW_SIZE = 10;
float windowBuffer[WINDOW_SIZE];
int bufferIndex = 0;
float windowSum = 0;

float applyMovingAverage(float rawValue) {
  windowSum -= windowBuffer[bufferIndex];
  windowBuffer[bufferIndex] = rawValue;
  windowSum += rawValue;
  bufferIndex = (bufferIndex + 1) % WINDOW_SIZE;
  return windowSum / WINDOW_SIZE;
}

void setup_wifi() {
  delay(10);
  Serial.print("Conectando a ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi Conectado!");
  Serial.print("IP asignada: ");
  Serial.println(WiFi.localIP());
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Intentando conexión MQTT...");
    if (client.connect("ESP32_FIRE_DETECTOR")) {
      Serial.println("¡Conectado al Broker MQTT!");
    } else {
      Serial.print("Fallo, rc=");
      Serial.print(client.state());
      Serial.println(" Reintentando en 2 segundos...");
      delay(2000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  
  for (int i = 0; i < WINDOW_SIZE; i++) {
    windowBuffer[i] = 0.0;
  }

  dht.begin();
  pinMode(MQ7PIN, INPUT);
  
  setup_wifi();
  client.setServer(mqtt_server, 1883);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    // Lectura de variables reales
    float temp = dht.readTemperature();
    float hum = dht.readHumidity();
    float raw_mq7 = analogRead(MQ7PIN);
    float filtered_mq7 = applyMovingAverage(raw_mq7);

    // Formateo del Payload JSON
    StaticJsonDocument<384> doc;
    doc["node_id"] = "ESP32_FIRE_DETECTION";
    
    JsonObject data = doc.createNestedObject("data");
    data["temp"] = isnan(temp) ? 0.0 : round(temp * 10.0) / 10.0;
    data["hum"] = isnan(hum) ? 0.0 : round(hum * 10.0) / 10.0;
    data["mq7_raw"] = raw_mq7;
    data["mq7_filt"] = round(filtered_mq7 * 10.0) / 10.0;
    
    doc["heap_free"] = ESP.getFreeHeap();

    char buffer[384];
    serializeJson(doc, buffer);

    // Publicación en el tópico MQTT
    client.publish("sensores/incendios/telemetria", buffer);
    Serial.print("Mensaje publicado vía MQTT: ");
    Serial.println(buffer);
  }
}